#include "Entity.h"
#include "Game.h"
#include <SDL.h>
#include "Loaders.h"

Entity::Entity()
{
}

Entity::~Entity()
{
}

