# BaseCode
Base Code for a video game programming course
It uses C++ and SDL
